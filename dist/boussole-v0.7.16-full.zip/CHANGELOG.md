# Changelog — Boussole

## v0.7.16 — 2026-02-09
- Décris ici l’unique amélioration en 1–3 phrases, concrètes.

## v0.7.15 — 2026-02-09
- Notes de version : lien “Voir tout” + modale changelog complet, bouton Copier.

## v0.7.14 — 2026-02-09
- Bump version/cache-busting uniquement.