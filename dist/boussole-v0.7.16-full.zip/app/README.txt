Boussole — v0.5.2.2

Dossier complet (tous fichiers).
- index.html : application
- dashboard.html : tableau de bord (optionnel)
- status.json : modèle (peut être remplacé par ton export)

Tout est local : pas de compte, pas de tracking, pas d’envoi automatique.
