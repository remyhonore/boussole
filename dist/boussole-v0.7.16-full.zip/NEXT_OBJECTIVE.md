# NEXT_OBJECTIVE
READY: no
TARGET_VERSION:
DATE_CREATED: 2026-02-09

## Objectif (1 idée)
- Décris ici l’unique amélioration en 1–3 phrases, concrètes.

## Contraintes (si spécifiques)
- Zéro changement fonctionnel hors objectif.
- Ne rien casser : landing, /app/, dashboard, exports/imports/PDF/modes test.
- Accessibilité : clavier + mobile OK.

## Définition de “done”
- Liste ultra courte : 2–4 critères max.

## Notes (optionnel)
- Captures, liens internes, contexte.
