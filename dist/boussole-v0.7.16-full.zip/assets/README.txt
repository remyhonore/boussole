README (assets)
Ce dossier contient des ressources statiques (icônes, favicons, images OG) pour la page racine /index.html.
Il n’est pas nécessaire au fonctionnement de l’app si tu ouvres directement /app/index.html.
